/*:
 * @plugindesc F6 Cheat Menu V3.0
 * @author TCT & Gemini
 * Phím G  = 71 F6 = 117
 */

(() => {

    Input.keyMapper[117] = "cheatMenu";

    const VIP_ITEMS = [48, 529, 530, 575, 576];
    const VIP_WEAPONS = [9, 10, 11];
    const VIP_ARMORS = [10, 77, 132, 133];

    window._cheatMenuLanguage = null;

// =====================================================================
    // MAP LINH THÚ → SWITCH (Ngăn trùng Đực/Cái)
    // =====================================================================
	/*
	const PET_OPPOSITE_MAP = {
        // Thanh Loan
        282: 283,   // Thanh Loan Cái  → Đực
        283: 282,   // Thanh Loan Đực → Cái
        // Hồ Ly
        284: 285,   // Hồ Ly Cái → Đực
        285: 284,   // Hồ Ly Đực → Cái
        // Long Nữ (Thanh Phù Du)
        286: 287,   // Thơ Ấu → Trưởng Thành
        287: 286,   // Trưởng Thành → Thơ Ấu
        // Thêm linh thú khác nếu cần (ID : ID đối nghịch)
    };*/
	const PET_OPPOSITE_MAP = {
		// Thanh Loan
		2: 3,   // Thanh Loan Đực → Cái
		3: 2,   // Thanh Loan Cái → Đực
		// Cửu Vĩ Hồ
		4: 5,   // Cửu Vĩ Hồ Đực → Cái
		5: 4,   // Cửu Vĩ Hồ Cái → Đực
		// Thanh Phù Du
		6: 7,   // Thanh Phù Du Ấu thể → Trưởng thành
		7: 6    // Thanh Phù Du Trưởng thành → Ấu thể
		// Thêm linh thú khác nếu cần (ID : ID đối nghịch)
	};
    // =====================================================================
    // ĐI XUYÊN TƯỜNG (NOCLIP)
    // =====================================================================
    window._cheatNoClip = window._cheatNoClip || false;
    const _Game_Player_isDebugThrough = Game_Player.prototype.isDebugThrough;
    Game_Player.prototype.isDebugThrough = function() {
        return window._cheatNoClip || _Game_Player_isDebugThrough.call(this);
    };

    // =====================================================================
    // HIỂN THỊ FPS OVERLAY
    // =====================================================================
    window._cheatFpsEnabled = false;
    let _fpsLastTime = performance.now();
    let _fpsFrames = 0;
    window._updateCheatFPS = function() {
        if (!window._cheatFpsEnabled) return;
        const now = performance.now();
        _fpsFrames++;
        if (now >= _fpsLastTime + 1000) {
            let fps = Math.round((_fpsFrames * 1000) / (now - _fpsLastTime));
            _fpsFrames = 0;
            _fpsLastTime = now;
            let el = document.getElementById('cheat-fps-meter');
            if (!el) {
                el = document.createElement('div');
                el.id = 'cheat-fps-meter';
                el.style.cssText = 'position:fixed; top:5px; left:5px; background:rgba(0,0,0,0.6); color:#00ffcc; border: 1px solid rgba(0,255,204,0.5); padding:4px 10px; border-radius:8px; font-weight:800; font-size:14px; z-index:999999; pointer-events:none; font-family: "Nunito", sans-serif; text-shadow: 0 2px 4px rgba(0,0,0,0.8); backdrop-filter: blur(4px); box-shadow: 0 4px 6px rgba(0,0,0,0.3);';
                document.body.appendChild(el);
            }
            el.innerText = 'FPS: ' + fps;
        }
        requestAnimationFrame(window._updateCheatFPS);
    };

    // =====================================================================
    // CSS GIAO DIỆN GLASSMORPHISM (AAA STANDARD) & THERUM GRID
    // =====================================================================
    const _addGlobalStyles = () => {
        if (!document.getElementById('cheat-glass-style')) {
            const styleEl = document.createElement('style');
            styleEl.id = 'cheat-glass-style';
            styleEl.innerHTML = `
                @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@500;700;800&display=swap');

                .cheat-overlay-box {
                    position: absolute; top: 2%; left: 5%; width: 90%; height: 96%;
                    background: rgba(18, 18, 24, 0.85);
                    backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    border-radius: 16px; display: flex; flex-direction: column;
                    z-index: 1000; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.1);
                    color: #fafafa; font-family: 'Nunito', sans-serif; overflow: hidden;
                }
                
                .cheat-tabs {
                    display: flex; overflow-x: auto; flex-shrink: 0;
                    background: rgba(0, 0, 0, 0.3); padding: 12px 15px; gap: 8px;
                    border-bottom: 1px solid rgba(255,255,255,0.05);
                }
                .cheat-tab-btn {
                    padding: 10px 20px; background: transparent; color: #a1a1aa;
                    border: 1px solid transparent; border-radius: 10px; cursor: pointer;
                    font-weight: 700; font-size: 15px; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
                    white-space: nowrap; font-family: inherit;
                }
                .cheat-tab-btn:hover { background: rgba(255,255,255,0.05); color: #fff; transform: translateY(-1px); }
                .cheat-tab-btn.active {
                    background: rgba(0, 255, 204, 0.15); color: #00ffcc;
                    border: 1px solid rgba(0, 255, 204, 0.3);
                    box-shadow: 0 4px 12px rgba(0, 255, 204, 0.15);
                }

                .cheat-content-area {
                    display: flex; flex: 1; padding: 20px; overflow-y: auto; flex-wrap: wrap;
                    gap: 20px; align-content: flex-start;
                }

                .cheat-col { flex: 1; min-width: 300px; display: flex; flex-direction: column; gap: 15px; }
                .cheat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 15px; width: 100%; align-content: start; }

                .cheat-card {
                    background: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.06);
                    border-radius: 12px; padding: 18px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.2);
                    transition: transform 0.2s, border-color 0.2s;
                }
                .cheat-card:hover { border-color: rgba(255,255,255,0.15); }

                /* ==================== SCROLLBAR ĐÃ TỐI ƯU CHO MOBILE ==================== */
                .cheat-content-area::-webkit-scrollbar,
                .cheat-grid::-webkit-scrollbar,
                .cheat-tabs::-webkit-scrollbar {
                    width: 14px;
                    height: 14px;
                }
                .cheat-content-area::-webkit-scrollbar-track,
                .cheat-grid::-webkit-scrollbar-track,
                .cheat-tabs::-webkit-scrollbar-track {
                    background: rgba(0, 0, 0, 0.5);
                    border-radius: 8px;
                }
                .cheat-content-area::-webkit-scrollbar-thumb,
                .cheat-grid::-webkit-scrollbar-thumb,
                .cheat-tabs::-webkit-scrollbar-thumb {
                    background: rgba(0, 255, 204, 0.65);
                    border-radius: 8px;
                    border: 3px solid transparent;
                    background-clip: padding-box;
                }
                .cheat-content-area::-webkit-scrollbar-thumb:hover,
                .cheat-grid::-webkit-scrollbar-thumb:hover,
                .cheat-tabs::-webkit-scrollbar-thumb:hover {
                    background: #00ffcc;
                }

                /* Scrollbar cho mobile (màn ngang) */
                @media (max-width: 800px) {
                    .cheat-content-area::-webkit-scrollbar,
                    .cheat-grid::-webkit-scrollbar,
                    .cheat-tabs::-webkit-scrollbar {
                        width: 16px;
                        height: 16px;
                    }
                    .cheat-content-area::-webkit-scrollbar-track,
                    .cheat-grid::-webkit-scrollbar-track,
                    .cheat-tabs::-webkit-scrollbar-track {
                        background: rgba(0, 0, 0, 0.6);
                    }
                    .cheat-content-area::-webkit-scrollbar-thumb,
                    .cheat-grid::-webkit-scrollbar-thumb,
                    .cheat-tabs::-webkit-scrollbar-thumb {
                        background: rgba(0, 255, 204, 0.8);
                    }
                }
                /* ================================================================== */

                /* Tích hợp Item Card từ TheRum */
                .tc-item-card {
                    background: rgba(24, 24, 27, 0.5); border: 1px solid rgba(255,255,255,0.05);
                    border-radius: 12px; padding: 12px; cursor: pointer; transition: all 0.2s;
                    display: flex; align-items: center; gap: 12px; position: relative; overflow: hidden;
                }
                .tc-item-card:hover {
                    border-color: #00ffcc; background: rgba(0, 255, 204, 0.05); transform: translateY(-2px);
                }
                .tc-item-icon { width: 32px; height: 32px; flex-shrink: 0; background: transparent; }
                .tc-item-info { display: flex; flex-direction: column; overflow: hidden; }
                .tc-item-name { font-weight: 700; font-size: 14px; color: #f4f4f5; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                .tc-item-desc { font-size: 11px; color: #a1a1aa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

                .tc-search {
                    padding: 8px 16px; border-radius: 8px; background: rgba(0,0,0,0.5);
                    border: 1px solid rgba(255,255,255,0.1); color: white; font-family: inherit; font-size: 14px; outline: none; transition: border-color 0.2s;
                    width: 250px; flex-shrink: 0;
                }
                .tc-search:focus { border-color: #00ffcc; box-shadow: 0 0 0 2px rgba(0,255,204,0.2); }

                .tc-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px 0 20px; gap: 15px; flex-wrap: wrap; }

                .cheat-card-title {
                    color: #fff; text-align: center; margin: 0 0 15px 0; padding-bottom: 12px;
                    border-bottom: 1px dashed rgba(255,255,255,0.1);
                    text-transform: uppercase; font-size: 16px; font-weight: 800; letter-spacing: 1px;
                }

                .cheat-input-row {
                    display: flex; justify-content: space-between; align-items: center;
                    margin-bottom: 8px; padding: 8px 12px; border-radius: 8px;
                    background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.03);
                    transition: all 0.2s;
                }
                .cheat-input-row:hover { background: rgba(0,0,0,0.4); border-color: rgba(255,255,255,0.1); }
                .cheat-input-label { font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; }
                
                .cheat-input {
                    width: 90px; padding: 6px 12px; background: rgba(0,0,0,0.5);
                    color: #00ffcc; border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 6px; text-align: right; font-size: 15px; font-weight: 800;
                    outline: none; transition: 0.2s; font-family: inherit;
                }
                .cheat-input:focus { border-color: #00ffcc; box-shadow: 0 0 0 2px rgba(0,255,204,0.2); background: rgba(0,0,0,0.8); }

                .cheat-btn {
                    padding: 12px 24px; font-weight: 800; border: none; border-radius: 10px;
                    cursor: pointer; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
                    font-family: inherit; font-size: 15px; display: inline-flex; align-items: center; justify-content: center;
                }
                .cheat-btn:hover { transform: translateY(-2px); }
                .cheat-btn:active { transform: translateY(0); }
                .btn-primary { background: linear-gradient(135deg, #00c6ff, #0072ff); color: #fff; box-shadow: 0 4px 15px rgba(0,114,255,0.3); }
                .btn-danger { background: linear-gradient(135deg, #ff416c, #ff4b2b); color: #fff; box-shadow: 0 4px 15px rgba(255,75,43,0.3); }
                .btn-success { background: linear-gradient(135deg, #11998e, #38ef7d); color: #fff; box-shadow: 0 4px 15px rgba(56,239,125,0.3); }
                .btn-secondary { background: rgba(255,255,255,0.1); color: #fff; border: 1px solid rgba(255,255,255,0.1); }
                .btn-secondary:hover { background: rgba(255,255,255,0.2); }

                .cheat-footer-container {
                    padding: 15px 20px; background: rgba(0, 0, 0, 0.4);
                    border-top: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: flex-end; gap: 12px;
                }

                /* MODAL */
                .tc-modal-overlay {
                    position: absolute; top: 0; left: 0; right: 0; bottom: 0;
                    background: rgba(0,0,0,0.6); display: flex; justify-content: center; align-items: center;
                    z-index: 2000; opacity: 0; pointer-events: none; transition: opacity 0.2s; backdrop-filter: blur(4px);
                }
                .tc-modal-overlay.active { opacity: 1; pointer-events: auto; }
                .tc-modal {
                    background: #121218; border: 1px solid #00ffcc; padding: 24px; border-radius: 16px; width: 320px;
                    display: flex; flex-direction: column; gap: 15px; transform: scale(0.9); transition: transform 0.2s;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
                }
                .tc-modal-overlay.active .tc-modal { transform: scale(1); }
                .tc-modal h3 { font-size: 18px; margin: 0; color: #00ffcc; text-align: center; }
                .tc-modal input {
                    padding: 12px; border-radius: 8px; background: rgba(255,255,255,0.05);
                    border: 1px solid rgba(255,255,255,0.1); color: white; font-family: inherit;
                    text-align: center; font-size: 20px; font-weight: bold; outline: none;
                }
                .tc-modal input:focus { border-color: #00ffcc; }
                .tc-modal-btns { display: flex; gap: 10px; }
                .tc-modal-btns button { flex: 1; padding: 12px; border-radius: 8px; border: none; font-family: inherit; font-weight: 700; cursor: pointer; transition: 0.2s; }
                .tc-modal-btns .btn-cancel { background: rgba(255,255,255,0.1); color: white; }
                .tc-modal-btns .btn-cancel:hover { background: rgba(255,255,255,0.2); }
                .tc-modal-btns .btn-ok { background: #00ffcc; color: #000; }
                .tc-modal-btns .btn-ok:hover { background: #00ccaa; }

                /* FIX JOIPLAY */
                .cheat-overlay-box input, .cheat-overlay-box select { pointer-events: auto !important; user-select: text !important; -webkit-user-select: text !important; touch-action: auto !important; }
                input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
                input[type=number] { -moz-appearance: textfield; }

                @media (max-width: 800px) {
                    .cheat-overlay-box { top: 0 !important; left: 0 !important; width: 100% !important; height: 100% !important; border-radius: 0 !important; border: none !important; }
                    .cheat-content-area { padding: 12px !important; flex-direction: column; flex-wrap: nowrap; overflow-x: hidden; }
                    .tc-header { flex-direction: column; align-items: stretch; padding: 10px; }
                    .tc-search { width: 100%; }
                    .cheat-btn { width: 100%; margin-bottom: 5px; padding: 16px !important; font-size: 16px !important; }
                    .cheat-footer-container { flex-direction: column-reverse; align-items: stretch !important; padding: 12px !important; }
                }
            `;
            document.head.appendChild(styleEl);
        }
    };
    _addGlobalStyles();

    // Hàm làm sạch text từ TheRum
    function cleanGameText(text) {
        if (!text) return "";
        return text.replace(/\\c\[\d+\]/gi, '').replace(/\\i\[\d+\]/gi, '').trim();
    }

    // Hàm vẽ Icon bằng Canvas từ TheRum
    function drawGameIconToCanvas(canvasElement, iconIndex) {
        if (!iconIndex || !canvasElement) return;
        const ctx = canvasElement.getContext('2d');
        const bitmap = ImageManager.loadSystem('IconSet');

        function executeDrawing() {
            const iconSize = 32;
            const iconsPerRow = 16;
            const sx = (iconIndex % iconsPerRow) * iconSize;
            const sy = Math.floor(iconIndex / iconsPerRow) * iconSize;
            
            const source = bitmap._canvas || bitmap._image;
            if (source) {
                ctx.clearRect(0, 0, iconSize, iconSize);
                ctx.drawImage(source, sx, sy, iconSize, iconSize, 0, 0, iconSize, iconSize);
            }
        }

        if (bitmap.isReady()) {
            executeDrawing();
        } else {
            bitmap.addLoadListener(executeDrawing);
        }
    }

    // =====================================================================
    // BỘ TỪ ĐIỂN DỊCH TỰ ĐỘNG
    // =====================================================================
    const LANG_DICT = {
        "🎒 LẤY VẬT PHẨM, TRANG PHỤC & LINH THÚ": "🎒 GET ITEMS, COSTUMES & PETS",
        "👤 CHỈNH SỬA NHÂN VẬT & LINH THÚ": "👤 EDIT ACTORS & PETS",
        "👶 QUẢN LÝ CHỈ SỐ CON CÁI": "👶 MANAGE CHILDREN STATS",
        "👥 QUẢN LÝ ĐẠO HỮU & TÌNH SỬ": "👥 MANAGE PARTNERS & H-HISTORY",
        "🌌 HỆ THỐNG DỊCH CHUYỂN & HỖ TRỢ": "🌌 TELEPORT & UTILITY SYSTEM",
        "💰 +1 Tỷ Linh Thạch & Vàng": "💰 +1 Billion Spirit Stones & Gold",
        "💊 Nhận Đan Dược VIP": "💊 Get VIP Pills",
        "🗡️ Nhận Trang Bị VIP": "🗡️ Get VIP Equipments",
        "📦 Nhận Item (Theo ID)": "📦 Get Item (By ID)",
        "⚔️ Nhận Vũ Khí/Giáp (Theo ID)": "⚔️ Get Weapon/Armor (By ID)",
        "⭐ Max Level Toàn Đội": "⭐ Max Level All Party",
        "📜 Học Tất Cả Skill": "📜 Learn All Skills",
        "🔥 Bật God Mode (Chỉ số 9999)": "🔥 God Mode (Stats 9999)",
        "💖 Hồi Full HP/MP": "💖 Full Heal HP/MP",
        "🔍 Tìm Item/Trang Bị Theo Tên": "🔍 Search Item/Gear By Name",
        "📋 Copy List Item/Trang Bị": "📋 Copy Item/Gear List",
        "🔢 Cộng Thêm Điểm Biến Số": "🔢 Add Variable Points",
        "📋 Copy List Biến Số": "📋 Copy Variables List",
        "🎚️ Bật/Tắt Công Tắc (Switch)": "🎚️ Toggle Switch (ON/OFF)",
        "📋 Copy List Công Tắc": "📋 Copy Switches List",
        "🎬 Gọi Sự Kiện Chung (End Game/Cốt truyện)": "🎬 Call Common Event (End Game/Story)",
        "💻 Chạy Mã Lệnh (Run Script)": "💻 Execute Script Call",
        
        "Vật Phẩm": "Items",
        "Vũ Khí": "Weapons",
        "Giáp": "Armors",
        "Vật Phẩm Quan Trọng": "Key Items",
        "Trang Phục": "Costumes",
        "Linh Thú": "Pets",
        "Tìm kiếm tên...": "Search name...",

        // Các dictionary khác
        "Đi Xuyên Tường": "NoClip (Walk through walls)",
        "Unlock Thư Viện Cảnh": "Unlock CG Gallery",
        "Hiển Thị FPS": "Show FPS",
        "Unlock All": "Unlock All",
        "Dịch Chuyển": "Teleport",
        "Bật": "ON",
        "Tắt": "OFF",
        "Nên Save Game trước khi sử dụng!\nBạn có chắc muốn dịch chuyển tới Map ID: ": "You should Save Game before using!\nAre you sure you want to teleport to Map ID: ",
		"CẢNH BÁO: Nếu Linh Thú đã có 1 loại Đực/Cái rồi thì nên chọn Loại Khác tránh chọn 1 loại 2 giới tính dễ lỗi SAVE!\nNếu Là Thanh Phù Du Ấu Thể/Trưởng Thành nên chọn 1 trong 2 không nên lấy cả 2 loại.\nBạn có chắc muốn tiếp tục?": "WARNING: If you already have a Male/Female Pet, please select a different species to prevent save file corruption!\nFor Dragon, please select either the Baby or Adult stage, not both.\nContinue?",
		"❌ Linh thú: ":"❌ Pet: ",
		" đã được kích hoạt rồi!\nKhông thể nhận trùng.":" has already been activated!\nCannot receive duplicates",
		"❌ Bạn đã có linh thú đối nghịch rồi!\nKhông thể nhận cả hai (Đực/Cái hoặc Ấu/Thành) để tránh lỗi save.":"❌ You already have a counter-spirit beast!\nYou cannot receive both (Male/Female or Cub/Adult) to avoid save errors.",
		"✅ Đã nhận linh thú: ":"✅ Pet has been received: ",
		"❌ Bạn đã có linh thú này rồi!":"❌ You already have this pet!",
		"❌ Bạn đã có linh thú đối nghịch trong đội hình!\n\nBạn có muốn XÓA con cũ và NHẬN con mới này không?":"❌ You already have a conflicting spirit beast in your party!\n\nDo you want to delete the current one and obtain this new spirit beast?",
        "CẢNH BÁO: Nên Save Game trước khi sử dụng!\nChức năng này sẽ tự động chạy mã lệnh để Mở Khóa Toàn Bộ Thư Viện Hồi Tưởng/CG.\nBạn có chắc muốn tiếp tục?": "WARNING: Save your game first!\nThis will automatically execute scripts to unlock all Gallery/CG Recalls.\nContinue?",
        "✅ Đã Mở Khóa Toàn Bộ Thư Viện Cảnh/CG thành công! Vui lòng kiểm tra ngoài Menu chính của game.": "✅ Successfully unlocked all CG/Gallery! Please check the Main Menu.",
        "Thuộc Tính Cơ Bản": "Basic Attributes",
        "Cấp độ (Level)": "Level",
        "EXP Hiện Có": "Current EXP",
        "EXP Lên Cấp": "Next Level EXP",
        "EXP Max Level": "Max Level EXP",
        "Sinh lực (HP)": "Health (HP)",
        "Linh lực (MP)": "Mana (MP)",
        "Công kích (ATK)": "Attack (ATK)",
        "Phòng ngự (DEF)": "Defense (DEF)",
        "Phép công (MAT)": "Magic Attack (MAT)",
        "Phép phòng ngự (MDF)": "Magic Defense (MDF)",
        "Thân pháp (AGI)": "Agility (AGI)",
        "Ngộ tính (LUK)": "Wisdom (LUK)",
        "Thông Tin Đặc Biệt": "Special Information",
        "Công Đức": "Merit",
        "Danh Vọng": "Reputation",
        "Linh Thạch": "Spirit Stones",
        "Tinh Khí": "Vital Essence",
        "Độ Thụ Thai": "Pregnancy Rate",
        "Tâm Ma": "Inner Demon",
        "Mị Lực": "Charm",
        "-- CÁC TIẾN ĐỘ --": "-- PROGRESSIONS --",
        "Đọa Lạc": "Depravity",
        "Tiến độ Miệng": "Mouth Progress",
        "Tiến độ Ngực": "Boobs Progress",
        "Tiến độ Bướm": "Pussy Progress",
        "Tiến độ Lỗ Nhị": "Anal Progress",
        "-- SỐ LẦN SỰ KIỆN --": "-- EVENT COUNTS --",
        "Số Lần Tự Sướng": "Masturbation Count",
        "Bị Quấy Rối": "Harassed Count",
        "Dụ Dỗ": "Seduced Count",
        "Song Tu": "Dual Cultivation Count",
        "Cưỡng Hiếp": "Raped Count",
        "Cưỡng Hiếp Tập Thể": "Gang Bang Count",
        "Kỹ Năng & Cấp Độ": "Skills & Level",
        "Nhân vật chưa có kỹ năng nào.": "Actor has no skills.",
        "ĐÓNG MÀN HÌNH": "CLOSE WINDOW",
        "LƯU LẠI": "SAVE CHANGES",
        "Trẻ Thứ": "Child",
        "Giai Đoạn Phát Triển": "Development Stage",
        "Tuổi": "Age",
        "Tháng": "Month",
        "Tình Cảm": "Affection",
        "Thể Lực": "Stamina",
        "Chỉ Số Tư Chất": "Aptitude Stats",
        "Nhan Sắc": "Beauty",
        "Trí Tuệ": "Intelligence",
        "Thể Chất": "Constitution",
        "Kỹ Năng Sống": "Survival Skills",
        "Lĩnh Ngộ": "Comprehension",
        "Thiện Lương": "Kindness",
        "Tà Ác": "Evil",
        "LƯU LẠI": "SAVE CHILD STATS",
        "HẢO CẢM & ĐẠO LỮ": "AFFECTION & PARTNERS",
        "KỶ LỤC TÌNH SỬ (H-STATS)": "H-HISTORY RECORDS",
        "ĐÓNG": "CLOSE",
        "LƯU LẠI": "SAVE AFFECTION",
        "Nhất Giai": "Stage 1",
        "Nhị Giai": "Stage 2",
        "Tam Giai": "Stage 3",
        "Tứ Giai": "Stage 4",
        "Ngũ Giai": "Stage 5",
        "(Đây là Linh Thú / Bạn đồng hành.<br>Các trạng thái tư mật chỉ áp dụng cho Nữ Chính.)": "(This is a Pet / Companion.<br>Private stats only apply to the Main Heroine.)",
        "✅ Đã lưu thành công mọi chỉ số cho ": "✅ Successfully saved all stats for ",
        "✅ Đã lưu thành công các chỉ số cho Đứa con thứ ": "✅ Successfully saved stats for Child ",
        "✅ Đã lưu thành công dữ liệu Tab hiện tại!": "✅ Successfully saved current Tab data!",
        "✅ Đã nhận 1 Tỷ Vàng, Linh Thạch & Thẻ Điểm!": "✅ Received 1 Billion Gold, Spirit Stones & Score Cards!",
        "✅ Đã nhận rương Đan Dược VIP!": "✅ Received VIP Pills chest!",
        "✅ Đã nhận Trang Bị VIP!": "✅ Received VIP Equipments!",
        "Nhập ID Item:": "Enter Item ID:",
        "❌ Không tồn tại Item ID này!": "❌ This Item ID does not exist!",
        "Số lượng muốn thêm:": "Amount to add:",
        "✅ Đã thêm ": "✅ Added ",
        "Nhập 1 để lấy Vũ Khí, Nhập 2 để lấy Giáp:": "Enter 1 for Weapon, Enter 2 for Armor:",
        "Nhập ID Trang bị:": "Enter Equipment ID:",
        "✅ Đã nhận Vũ khí: ": "✅ Received Weapon: ",
        "✅ Đã nhận Giáp: ": "✅ Received Armor: ",
        "❌ Không tồn tại ID trang bị này!": "❌ This Equipment ID does not exist!",
        "✅ Tất cả thành viên đã Max Level!": "✅ All members have reached Max Level!",
        "✅ Đã hack học toàn bộ Skill trong game!": "✅ Learned all Skills in the game!",
        "✅ Đã buff chỉ số lên 9999 (God Mode)!": "✅ Buffed stats to 9999 (God Mode)!",
        "✅ Đã hồi phục hoàn toàn máu và mana!": "✅ Fully restored HP and MP!",
        "Biến ẩn/Không tên": "Hidden/Unnamed Variable",
        "Công tắc ẩn/Không tên": "Hidden/Unnamed Switch",
        "Nhập ID Biến số (Variable ID) muốn thao tác:\n(Mở Copy List Biến Số để tra ID)": "Enter Variable ID to modify:\n(Use Copy Variables List to find ID)",
        "Nhập ID Công Tắc (Switch ID) muốn BẬT/TẮT:": "Enter Switch ID to ON/OFF:",
        "Chỉ số [": "Stat [",
        "Công tắc [": "Switch [",
        "] hiện tại đang là: ": "] is currently: ",
        "] đang ": "] is ",
        "\nNhập số điểm muốn CỘNG THÊM (Nhập số âm dấu trừ để giảm):": "\nEnter amount to ADD (Enter negative to subtract):",
        ".\nNhập 1 để BẬT, nhập 0 để TẮT:": ".\nEnter 1 for ON, 0 for OFF:",
        "✅ Đã cộng thêm ": "✅ Added ",
        " vào [": " to [",
        "].\nTổng hiện tại: ": "].\nCurrent total: ",
        "✅ Đã ": "✅ Successfully turned ",
        " công tắc [": " switch [",
        "--- DANH SACH ITEM ---\n": "--- ITEM LIST ---\n",
        "\n--- DANH SACH VU KHI ---\n": "\n--- WEAPON LIST ---\n",
        "\n--- DANH SACH GIAP ---\n": "\n--- ARMOR LIST ---\n",
        "✅ Đã Copy toàn bộ ID Vật phẩm/Vũ khí/Giáp!\nRa ngoài mở Notepad Paste (Ctrl+V) ra xem.": "✅ Copied all Item/Weapon/Armor IDs!\nOpen Notepad and Paste (Ctrl+V) to view.",
        "--- DANH SACH BIEN SO (VARIABLES) ---\n": "--- VARIABLES LIST ---\n",
        "✅ Đã Copy danh sách Biến!\nRa ngoài mở Notepad Paste (Ctrl+V) để tra ID.": "✅ Copied Variables List!\nOpen Notepad and Paste (Ctrl+V) to search ID.",
        "--- DANH SACH CONG TAC (SWITCHES) ---\n": "--- SWITCHES LIST ---\n",
        "✅ Đã Copy danh sách Công Tắc!\nRa ngoài mở Notepad Paste (Ctrl+V) để tra ID.": "✅ Copied Switches List!\nOpen Notepad and Paste (Ctrl+V) to search ID.",
        "Nhập tên cần tìm (VD: Thanh, Dan, Kiem):": "Enter name to search (E.g: Sword, Potion):",
        "❌ Không tìm thấy món nào tên: ": "❌ Could not find any item named: ",
        "✅ Đã tìm thấy và COPY vào Clipboard!\nRa ngoài mở Notepad rồi Paste (Ctrl+V) ra xem ID nhé.": "✅ Found and COPIED to Clipboard!\nOpen Notepad and Paste (Ctrl+V) to see IDs.",
        "Nhập ID Sự Kiện Chung (Common Event ID) muốn gọi:\n(Dùng Notepad++ quét thư mục data để tìm ID sự kiện End Game)": "Enter Common Event ID to call:\n(Use Notepad++ to search 'data' folder for the End Game event ID)",
        "❌ Không tồn tại Sự Kiện này!": "❌ This Event does not exist!",
        "Nhập mã Script Call cần chạy:\n(Ví dụ: $gameSystem.unlockAllCgs();)": "Enter Script Call to execute:\n(Example: $gameSystem.unlockAllCgs();)",
        "✅ Đã thực thi mã lệnh thành công!": "✅ Executed script successfully!",
        "❌ Lỗi khi thực thi mã lệnh: ": "❌ Error executing script: ",
        "Vật phẩm [": "Item [",
        "Trang bị [": "Equipment [",
        "] hiện có: ": "] currently have: ",
		"Nhận: ":"Received: ",
        "\nNhập số lượng muốn thêm:": "\nEnter amount to add:"
    };

    function T(text) {
        if (window._cheatMenuLanguage === 'EN' && LANG_DICT[text] !== undefined) {
            return LANG_DICT[text];
        }
        return text;
    }
	
	// Kiểm tra linh thú đã kích hoạt qua Switch
    function isPetAlreadyActivated(switchId) {
        if (switchId && $gameSwitches) {
            return $gameSwitches.value(switchId) === true;
        }
        return false;
    }
	// Kiểm tra đã có linh thú đối nghịch trong kho chưa
    function hasOppositePet(petActorId) {
        if (!$gameSystem._petActorList || $gameSystem._petActorList.length === 0) return false;
        
        const oppositeId = PET_OPPOSITE_MAP[petActorId];
        if (!oppositeId) return false;

        return $gameSystem._petActorList.some(p => p.id === oppositeId);
    }
	
    const CHILDREN_VARS = {
        1: { nhanSac: 725, triTue: 726, theChat: 727, sinhTon: 728, taAc: 729, linhNgo: 730, thienLuong: 731, thang: 734, tuoi: 735, ngoaiHinh: 736, tinhCam: 737, theLuc: 738 },
        2: { nhanSac: 742, triTue: 743, theChat: 744, sinhTon: 745, taAc: 746, linhNgo: 747, thienLuong: 748, tinhCam: 749, theLuc: 750, thang: 751, tuoi: 752, ngoaiHinh: 753 },
        3: { nhanSac: 756, triTue: 757, theChat: 758, sinhTon: 759, taAc: 760, linhNgo: 761, thienLuong: 762, tinhCam: 763, theLuc: 764, thang: 765, tuoi: 766, ngoaiHinh: 767 },
        4: { nhanSac: 770, triTue: 771, theChat: 772, sinhTon: 773, taAc: 774, linhNgo: 775, thienLuong: 776, tinhCam: 777, theLuc: 778, thang: 779, tuoi: 780, ngoaiHinh: 781 },
        5: { nhanSac: 784, triTue: 785, theChat: 786, sinhTon: 787, taAc: 788, linhNgo: 789, thienLuong: 790, tinhCam: 791, theLuc: 792, thang: 793, tuoi: 794, ngoaiHinh: 795 }
    };

    function getTierName(val) {
        const v = parseInt(val) || 0;
        if (v >= 1001) return T("Ngũ Giai");
        if (v >= 601) return T("Tứ Giai"); 
        if (v >= 301) return T("Tam Giai");
        if (v >= 101) return T("Nhị Giai");
        return T("Nhất Giai"); 
    }
    function getTierNameDoaLac(val) {
        const v = parseInt(val) || 0;
        if (v >= 4001) return T("Ngũ Giai");
        if (v >= 2001) return T("Tứ Giai"); 
        if (v >= 501) return T("Tam Giai");
        if (v >= 101) return T("Nhị Giai");
        return T("Nhất Giai"); 
    }

    function createInputRow(label, id, val, color = "#fff", extraInfo = "") {
        let infoSpan = extraInfo ? `<span style="font-size: 11px; opacity: 0.5; margin-left: 6px; font-weight: normal;">${extraInfo}</span>` : "";
        return `
            <div class="cheat-input-row">
                <span class="cheat-input-label" style="color:${color}">${label}${infoSpan}</span>
                <input type="number" id="${id}" value="${val}" class="cheat-input" onfocus="this.select()">
            </div>
        `;
    }
    function createInputRowWithTierDoaLac(label, id, val, extraInfo = "") {
        let tier = getTierNameDoaLac(val);
        let infoSpan = extraInfo ? `<span style="font-size: 11px; opacity: 0.5; margin-left: 6px; font-weight: normal;">${extraInfo}</span>` : "";
        return `
            <div class="cheat-input-row">
                <span class="cheat-input-label">${label}${infoSpan} <b id="tier-${id}" style="color:#ff6699; font-size:12px; margin-left:5px; background: rgba(255,102,153,0.1); padding: 2px 6px; border-radius: 4px;">[${tier}]</b></span>
                <input type="number" id="${id}" value="${val}" class="cheat-input tier-input" data-id="${id}" onfocus="this.select()">
            </div>
        `;
    }
	
    function createInputRowWithTier(label, id, val, extraInfo = "") {
        let tier = getTierName(val);
        let infoSpan = extraInfo ? `<span style="font-size: 11px; opacity: 0.5; margin-left: 6px; font-weight: normal;">${extraInfo}</span>` : "";
        return `
            <div class="cheat-input-row">
                <span class="cheat-input-label">${label}${infoSpan} <b id="tier-${id}" style="color:#ff6699; font-size:12px; margin-left:5px; background: rgba(255,102,153,0.1); padding: 2px 6px; border-radius: 4px;">[${tier}]</b></span>
                <input type="number" id="${id}" value="${val}" class="cheat-input tier-input" data-id="${id}" onfocus="this.select()">
            </div>
        `;
    }

    function createSmallInputRow(label, id, val, color = "#66ccff", extraInfo = "") {
        let infoSpan = extraInfo ? `<span style="font-size: 11px; opacity: 0.5; margin-left: 6px; font-weight: normal;">${extraInfo}</span>` : "";
        return `
            <div class="cheat-input-row" style="background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.05);">
                <span class="cheat-input-label" style="color:${color}; font-size: 13px;">${label}${infoSpan}</span>
                <input type="number" id="${id}" value="${val}" class="cheat-input" onfocus="this.select()" style="width: 75px; font-size: 14px; padding: 4px 8px;">
            </div>
        `;
    }

    function applyJoiPlayTouchFix(containerId) {
        document.querySelectorAll(`#${containerId} input, #${containerId} select`).forEach(el => {
            const focusFunc = function(e) {
                e.stopPropagation(); 
                this.focus();        
                if(this.select) this.select();
            };
            el.addEventListener('touchstart', focusFunc, { passive: false });
            el.addEventListener('pointerdown', focusFunc);
            el.addEventListener('mousedown', focusFunc);
        });
    }

    // =====================================================================
    // TẠO CỬA SỔ MENU (WINDOW)
    // =====================================================================
    function Window_CheatMenu() { this.initialize(...arguments); }
    Window_CheatMenu.prototype = Object.create(Window_Command.prototype);
    Window_CheatMenu.prototype.constructor = Window_CheatMenu;
    Window_CheatMenu.prototype.initialize = function(rect) { Window_Command.prototype.initialize.call(this, rect); };

    Window_CheatMenu.prototype.makeCommandList = function() {
        this.addCommand(T("🎒 LẤY VẬT PHẨM, TRANG PHỤC & LINH THÚ"), "cmd_items_ui");
        this.addCommand(T("👤 CHỈNH SỬA NHÂN VẬT & LINH THÚ"), "cmd_ui");
        this.addCommand(T("👶 QUẢN LÝ CHỈ SỐ CON CÁI"), "cmd_children");
        this.addCommand(T("👥 QUẢN LÝ ĐẠO HỮU & TÌNH SỬ"), "cmd_daohuu");
        this.addCommand(T("🌌 HỆ THỐNG DỊCH CHUYỂN & HỖ TRỢ"), "cmd_teleport");
        this.addCommand(T("💰 +1 Tỷ Linh Thạch & Vàng"), "cmd1");
        this.addCommand(T("💊 Nhận Đan Dược VIP"), "cmd2");
        this.addCommand(T("🗡️ Nhận Trang Bị VIP"), "cmd3");
        this.addCommand(T("⭐ Max Level Toàn Đội"), "cmd7");
        this.addCommand(T("📜 Học Tất Cả Skill"), "cmd8");
        this.addCommand(T("🔥 Bật God Mode (Chỉ số 9999)"), "cmd9");
        this.addCommand(T("💖 Hồi Full HP/MP"), "cmd14");
        this.addCommand(T("🔢 Cộng Thêm Điểm Biến Số"), "cmd15"); 
        this.addCommand(T("📋 Copy List Biến Số"), "cmd16");
        this.addCommand(T("📋 Copy List Item/Trang Bị"), "cmd10");
    };
    Window_CheatMenu.prototype.itemHeight = function() { return Math.floor(this.lineHeight() * 1.5); };

    // =====================================================================
    // TẠO SCENE CHỨA MENU
    // =====================================================================
    function Scene_CheatMenu() { this.initialize(...arguments); }
    Scene_CheatMenu.prototype = Object.create(Scene_MenuBase.prototype);
    Scene_CheatMenu.prototype.constructor = Scene_CheatMenu;
    Scene_CheatMenu.prototype.initialize = function() { Scene_MenuBase.prototype.initialize.call(this); };
    Scene_CheatMenu.prototype.create = function() {
        Scene_MenuBase.prototype.create.call(this);
        this.createCheatWindow();
    };

    Scene_CheatMenu.prototype.createCheatWindow = function() {
        const rect = this.cheatWindowRect();
        this._cheatWindow = new Window_CheatMenu(rect);
        this._cheatWindow.setHandler("cancel", this.popScene.bind(this));
        
        // Liên kết Scene Menu mới
        this._cheatWindow.setHandler("cmd_items_ui", this.cmdOpenItemsUI.bind(this));
        
        this._cheatWindow.setHandler("cmd_ui", this.cmdOpenUI.bind(this));
        this._cheatWindow.setHandler("cmd_children", this.cmdOpenChildrenUI.bind(this));
        this._cheatWindow.setHandler("cmd_daohuu", this.cmdOpenDaoHuuUI.bind(this));
        this._cheatWindow.setHandler("cmd_teleport", this.cmdOpenTeleportUI.bind(this));
        this._cheatWindow.setHandler("cmd1", this.cmdGold.bind(this));
        this._cheatWindow.setHandler("cmd2", this.cmdVipItems.bind(this));
        this._cheatWindow.setHandler("cmd3", this.cmdVipGear.bind(this));
        this._cheatWindow.setHandler("cmd7", this.cmdMaxLevel.bind(this));
        this._cheatWindow.setHandler("cmd8", this.cmdAllSkills.bind(this));
        this._cheatWindow.setHandler("cmd9", this.cmdGodMode.bind(this));
        this._cheatWindow.setHandler("cmd10", this.cmdListAllItems.bind(this));
        this._cheatWindow.setHandler("cmd14", this.cmdFullHeal.bind(this));
        this._cheatWindow.setHandler("cmd15", this.cmdAddVariable.bind(this));
        this._cheatWindow.setHandler("cmd16", this.cmdListVariables.bind(this));
        this.addWindow(this._cheatWindow);
    };

    Scene_CheatMenu.prototype.cheatWindowRect = function() {
        const ww = 500;
        const wh = Graphics.boxHeight - 40; 
        const wx = (Graphics.boxWidth - ww) / 2;
        const wy = (Graphics.boxHeight - wh) / 2;
        return new Rectangle(wx, wy, ww, wh);
    };

    // =====================================================================
    // GIAO DIỆN LẤY ITEMS, TRANG PHỤC, LINH THÚ (KẾT HỢP TỪ THERUM)
    // =====================================================================
    Scene_CheatMenu.prototype.cmdOpenItemsUI = function() {
        SoundManager.playEquip();
        this.popScene(); 
        if (document.getElementById('cheat-items-ui')) return;

        let currentCat = 'item';
        let searchKeyword = '';
        let selectedItem = null;

        const overlay = document.createElement('div');
        overlay.id = 'cheat-items-ui';
        overlay.className = 'cheat-overlay-box';

        // CHẶN HOÀN TOÀN NHẬN PHÍM/CHUỘT XUYÊN XUỐNG GAME
        overlay.addEventListener('mousedown', e => e.stopPropagation());
        overlay.addEventListener('touchstart', e => e.stopPropagation());
        overlay.addEventListener('pointerdown', e => e.stopPropagation());
        overlay.addEventListener('wheel', e => e.stopPropagation());
        
        // FIX LỖI NHÂN VẬT DI CHUYỂN KHI MỞ MENU
        overlay.addEventListener('keydown', e => {
            e.stopPropagation(); // Ngăn RPG Maker bắt WASD/Arrow Keys
            if (e.key === 'Escape') {
                if (document.getElementById('tc-qty-modal').classList.contains('active')) {
                    closeModal();
                } else {
                    closeUI();
                }
            }
        });
        overlay.addEventListener('keyup', e => e.stopPropagation());

        let html = `
            <div class="tc-header">
                <div class="cheat-tabs" style="border:none; padding:0; background:transparent;">
                    <button class="cheat-tab-btn active" data-cat="item">${T("Vật Phẩm")}</button>
                    <button class="cheat-tab-btn" data-cat="weapon">${T("Vũ Khí")}</button>
                    <button class="cheat-tab-btn" data-cat="armor">${T("Giáp")}</button>
                    <button class="cheat-tab-btn" data-cat="keyItem">${T("Vật Phẩm Quan Trọng")}</button>
                    <button class="cheat-tab-btn" data-cat="costume" style="color:#ff6699;">${T("Trang Phục")}</button>
                    <button class="cheat-tab-btn" data-cat="pet" style="color:#ffcc00;">${T("Linh Thú")}</button>
                </div>
                <input type="text" class="tc-search" id="tc-search-input" placeholder="${T("Tìm kiếm tên...")}" autocomplete="off">
            </div>
            
            <div class="cheat-content-area" style="padding-top: 10px;">
                <div class="cheat-grid" id="tc-grid"></div>
            </div>
            
            <div class="cheat-footer-container">
                <button id="btn-items-close" class="cheat-btn btn-secondary">${T("ĐÓNG MÀN HÌNH")}</button>
            </div>

            <div class="tc-modal-overlay" id="tc-qty-modal">
                <div class="tc-modal">
                    <h3 id="tc-modal-title">Nhập số lượng</h3>
                    <input type="number" id="tc-modal-input" value="1" min="1" max="9999" onfocus="this.select()">
                    <div class="tc-modal-btns">
                        <button class="btn-cancel" id="btn-modal-cancel">Hủy</button>
                        <button class="btn-ok" id="btn-modal-ok">Nhận</button>
                    </div>
                </div>
            </div>
        `;
        overlay.innerHTML = html;
        document.body.appendChild(overlay);

        const renderGrid = () => {
            const grid = document.getElementById('tc-grid');
            grid.innerHTML = '';

            let items = [];
            // Logic lọc data từ game
            if (currentCat === 'item') items = $dataItems.filter(i => i && i.name && i.itypeId === 1);
            else if (currentCat === 'keyItem') items = $dataItems.filter(i => i && i.name && i.itypeId === 2);
            else if (currentCat === 'weapon') items = $dataWeapons.filter(i => i && i.name);
            else if (currentCat === 'armor') items = $dataArmors.filter(i => i && i.name);
            else if (currentCat === 'costume') {
                [$dataItems, $dataArmors].forEach(list => {
                    if(list) list.forEach(i => {
                        if (i && i.name && i.note && i.note.includes('<时装序列>')) items.push(i);
                    });
                });
            }
            else if (currentCat === 'pet') {
                items = $dataActors.filter(i => i && i.name && (i.note.includes('宠物') || i.note.includes('宠物立绘')));
                items.forEach(i => { i.iconIndex = i.iconIndex || 193; i.description = i.profile || "Linh thú"; });
            }

            // Tìm kiếm
            if (searchKeyword) {
                items = items.filter(i => cleanGameText(i.name).toLowerCase().includes(searchKeyword.toLowerCase()));
            }

            // Xóa rác
            items = items.filter(i => cleanGameText(i.name) !== '');

            items.forEach(item => {
                const card = document.createElement('div');
                card.className = 'tc-item-card';
                card.innerHTML = `
                    <canvas class="tc-item-icon" width="32" height="32"></canvas>
                    <div class="tc-item-info">
                        <div class="tc-item-name">${cleanGameText(item.name)}</div>
                        <div class="tc-item-desc">${cleanGameText(item.description)}</div>
                    </div>
                `;
                const canvas = card.querySelector('.tc-item-icon');
                drawGameIconToCanvas(canvas, item.iconIndex);

                card.onclick = () => {
					    // Chỉ xử lý nếu là linh thú (có chứa dữ liệu hình ảnh character hoặc face)
					if (item.characterName !== undefined || item.faceName !== undefined) {
						const petName = cleanGameText(item.name);
						const petId = item.id;

						// 1. Kiểm tra giới tính Đực/Cái hoặc ấu thể/trưởng thành
						// PET_OPPOSITE_MAP đã có sẵn trong mã của bạn, logic này kiểm tra 
						// xem trong danh sách linh thú hiện tại đã có con "đối nghịch" chưa.
						if (confirm(T("CẢNH BÁO: Nếu Linh Thú đã có 1 loại Đực/Cái rồi thì nên chọn Loại Khác tránh chọn 1 loại 2 giới tính dễ lỗi SAVE!\nNếu Là Thanh Phù Du Ấu Thể/Trưởng Thành nên chọn 1 trong 2 không nên lấy cả 2 loại.\nBạn có chắc muốn tiếp tục?")))
						{						
							/*
							if (hasOppositePet(petId)) {
								SoundManager.playBuzzer();
								alert(T("❌ Bạn đã có linh thú đối nghịch rồi!\nKhông thể nhận cả hai (Đực/Cái hoặc Ấu/Thành) để tránh lỗi save."));
								return;
							}*/
							if (hasOppositePet(petId)) 
							{
								SoundManager.playBuzzer();
								const oppositeId = PET_OPPOSITE_MAP[petId];
								// Hiện thông báo hỏi người dùng
								let confirmDelete = confirm(T("❌ Bạn đã có linh thú đối nghịch trong đội hình!\n\nBạn có muốn XÓA con cũ và NHẬN con mới này không?"));
								if (confirmDelete) 
								{
									// Tìm và xóa con cũ có ID đối nghịch
									$gameSystem._petActorList = $gameSystem._petActorList.filter(p => p.id !== oppositeId);
									
									// Thêm con mới vào
									$gameSystem._petActorList.push(item);
									
									SoundManager.playUseSkill();
									alert(T("✅ Đã thay thế linh thú thành công!"));
									return;
								} else {
									// Người dùng chọn hủy
									return;
								}
							}
							// 2. Kiểm tra nếu đã nhận đúng con đó rồi thì không cho nhận nữa
							if (!$gameSystem._petActorList) $gameSystem._petActorList = [];
							if ($gameSystem._petActorList.some(p => p.id === petId)) {
								SoundManager.playBuzzer();
								alert(T("❌ Bạn đã có linh thú này rồi!"));
								return;
							}
								$gameSystem._petActorList.push(item);
								SoundManager.playUseSkill();
								alert(T("✅ Đã nhận linh thú: ") + petName);

						// 3. Thực hiện thêm vào danh sách
						}
						return;
					}
					/* Lỗi
					if (item.characterName !== undefined || item.faceName !== undefined) {
                        const petName = cleanGameText(item.name);
                        const petId = item.id;                    // ID Actor
                        const switchId = Object.keys(PET_OPPOSITE_MAP).find(key => parseInt(key) === petId) 
                                      || Object.values(PET_OPPOSITE_MAP).find(val => val === petId);
                        // CHECK 1: ĐÃ KÍCH HOẠT QUA SWITCH
                        if (switchId && isPetAlreadyActivated(parseInt(switchId))) {
                            SoundManager.playBuzzer();
                            //alert(`❌ Linh thú ${petName} đã được kích hoạt rồi!\nKhông thể nhận trùng.`);
							alert(T("❌ Linh thú: ") + petName + T(" đã được kích hoạt rồi!\nKhông thể nhận trùng."));
                            return;
                        }
                        // CHECK 2: ĐÃ CÓ LINH THÚ ĐỐI NGHỊCH TRONG KHO
                        if (hasOppositePet(petId)) {
                            SoundManager.playBuzzer();
                            //alert(`❌ Bạn đã có linh thú đối nghịch rồi!\nKhông thể nhận cả hai (Đực/Cái hoặc Ấu/Thành) để tránh lỗi save.`);
							alert(T("❌ Bạn đã có linh thú đối nghịch rồi!\nKhông thể nhận cả hai (Đực/Cái hoặc Ấu/Thành) để tránh lỗi save."));
                            return;
                        }
                        // Confirm cuối
                        if (confirm(T("CẢNH BÁO: Nếu Linh Thú đã có 1 loại Đực/Cái rồi thì nên chọn Loại Khác tránh chọn 1 loại 2 giới tính dễ lỗi SAVE!\nNếu Là Thanh Phù Du Ấu Thể/Trưởng Thành nên chọn 1 trong 2 không nên lấy cả 2 loại.\nBạn có chắc muốn tiếp tục?"))) {
                            if (!$gameSystem._petActorList) $gameSystem._petActorList = [];
                            
                            if (!$gameSystem._petActorList.some(p => p.id === petId)) {
                                $gameSystem._petActorList.push(item);
                                SoundManager.playUseSkill();
                                //alert(`✅ Đã nhận linh thú: ${petName}`);
								alert(T("✅ Đã nhận linh thú: ") + petName);
                            } else {
                                SoundManager.playBuzzer();
                                //alert(`❌ Bạn đã có linh thú này rồi!`);
								alert(T("❌ Bạn đã có linh thú này rồi!"));
                            }
                        }
                        return;
                    }*/
					/* === PHẦN XỬ LÝ LINH THÚ ===
                    if (item.characterName !== undefined || item.faceName !== undefined) {
                        const petName = cleanGameText(item.name);
						if(confirm(T("CẢNH BÁO: Nếu Linh Thú đã có 1 loại Đực/Cái rồi thì nên chọn Loại Khác tránh chọn 1 loại 2 giới tính dễ lỗi SAVE!\nNếu Là Thanh Phù Du Ấu Thể/Trưởng Thành nên chọn 1 trong 2 không nên lấy cả 2 loại.\nBạn có chắc muốn tiếp tục?")))
						{
							if (isPetAlreadyActivated(petName)) 
							{
								SoundManager.playBuzzer();
								alert(`❌ Linh thú ${petName} đã được kích hoạt rồi!\nKhông thể nhận trùng loại Đực/Cái.`);
								return;
							} else {
								if (!$gameSystem._petActorList) $gameSystem._petActorList = [];
								if (!$gameSystem._petActorList.some(p => p.id === item.id)) {
									$gameSystem._petActorList.push(item);
									SoundManager.playUseSkill();
									alert(`✅ Đã nhận linh thú: ${petName}`);
								} else {
									SoundManager.playBuzzer();
									alert(`❌ Bạn đã có linh thú này rồi!`);
								}
							}
						}
                        return;
					}*/
                    // Vật phẩm bình thường
                    selectedItem = item;
                    //document.getElementById('tc-modal-title').innerText = 'T("Nhận: ") + ${cleanGameText(item.name))}`;
					document.getElementById('tc-modal-title').innerText = T("Nhận: ") + cleanGameText(item.name);
					//document.getElementById('tc-modal-title').innerText = `Nhận: ${cleanGameText(item.name)}`;
                    document.getElementById('tc-modal-input').value = 1;
                    document.getElementById('tc-qty-modal').classList.add('active');
                    document.getElementById('tc-modal-input').focus();
                };
                grid.appendChild(card);
            });
        };

        const closeModal = () => {
            document.getElementById('tc-qty-modal').classList.remove('active');
            selectedItem = null;
        };

        // Gán sự kiện Modal
        document.getElementById('btn-modal-cancel').onclick = closeModal;
        document.getElementById('btn-modal-ok').onclick = () => {
            if (!selectedItem) return;
            let qty = parseInt(document.getElementById('tc-modal-input').value, 10);
            if (isNaN(qty) || qty <= 0) { SoundManager.playBuzzer(); return; }
            $gameParty.gainItem(selectedItem, qty);
            SoundManager.playUseItem();
            alert(`✅ Đã nhận ${qty}x ${cleanGameText(selectedItem.name)}`);
            closeModal();
        };

        // Xử lý nút tìm kiếm
        const searchInput = document.getElementById('tc-search-input');
        searchInput.addEventListener('input', (e) => {
            searchKeyword = e.target.value;
            renderGrid();
        });
        searchInput.addEventListener('keydown', e => {
            e.stopPropagation(); // Khóa cứng phím K và phím di chuyển khi đang nhập
            if (e.key === 'Enter' && selectedItem == null) searchInput.blur();
            if (e.key === 'Escape') searchInput.blur();
        });

        // Xử lý Tabs
        document.querySelectorAll('#cheat-items-ui .cheat-tab-btn').forEach(btn => {
            btn.onclick = (e) => {
                document.querySelectorAll('#cheat-items-ui .cheat-tab-btn').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                currentCat = e.target.getAttribute('data-cat');
                SoundManager.playCursor();
                renderGrid();
            };
        });

        const closeUI = () => {
            SoundManager.playCancel();
            document.body.removeChild(overlay);
            Input.clear(); TouchInput.clear();
        };
        document.getElementById('btn-items-close').onclick = closeUI;

        applyJoiPlayTouchFix('cheat-items-ui');
        Input.clear(); TouchInput.clear();
        renderGrid();
    };

    // =====================================================================
    // CÁC GIAO DIỆN CŨ (ĐÃ ADD THÊM CHẶN SỰ KIỆN PHÍM ĐỂ NHÂN VẬT KHÔNG DI CHUYỂN)
    // =====================================================================

    Scene_CheatMenu.prototype.cmdOpenTeleportUI = function() {
        SoundManager.playEquip();
        this.popScene(); 
        if (document.getElementById('cheat-teleport-ui')) return;

        const overlay = document.createElement('div');
        overlay.id = 'cheat-teleport-ui';
        overlay.className = 'cheat-overlay-box';

        overlay.addEventListener('mousedown', e => e.stopPropagation());
        overlay.addEventListener('touchstart', e => e.stopPropagation());
        overlay.addEventListener('pointerdown', e => e.stopPropagation());
        // FIX LỖI PHÍM
        overlay.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeFunc(); });
        overlay.addEventListener('keyup', e => e.stopPropagation());

        let mapGroups = [];
        if (window.$dataMapInfos) {
            let validMaps = $dataMapInfos.filter(m => m && m.name);
            let roots = validMaps.filter(m => m.parentId === 0);
            let orphans = validMaps.filter(m => m.parentId !== 0 && !validMaps.find(r => r.id === m.parentId));
            roots = roots.concat(orphans); 

            roots.forEach(root => {
                let group = { parent: root, children: [] };
                let getChildren = (pId, depth) => {
                    let children = validMaps.filter(m => m.parentId === pId);
                    children.sort((a,b) => a.order - b.order).forEach(c => {
                        group.children.push({ map: c, prefix: "—".repeat(depth) });
                        getChildren(c.id, depth + 1);
                    });
                };
                group.children.push({ map: root, prefix: "" });
                getChildren(root.id, 1);
                mapGroups.push(group);
            });
        }

        let closeFunc; // Khai báo trước để dùng trong keydown

        const renderTeleportUI = () => {
            let headerHTML = `
                <div style="padding: 18px; background: rgba(0,0,0,0.4); border-bottom: 1px solid rgba(255,255,255,0.05); text-align:center;">
                    <h2 style="margin:0; color:#00ffcc; font-weight: 800; letter-spacing: 1px; text-transform: uppercase;">${T("🌌 HỆ THỐNG DỊCH CHUYỂN & HỖ TRỢ")}</h2>
                </div>
            `;
            let contentHTML = `<div class="cheat-content-area" style="display:block;">`;
            contentHTML += `<div class="cheat-card" style="margin-bottom: 20px; display: flex; flex-direction: column; gap: 10px;">`;
            contentHTML += `
                <div class="cheat-input-row" style="background: rgba(0,0,0,0.3);">
                    <span style="font-size: 15px; color:#ffff66; font-weight:700;">${T("Hiển Thị FPS")}</span>
                    <button id="btn-toggle-fps" class="cheat-btn ${window._cheatFpsEnabled ? 'btn-success' : 'btn-secondary'}" style="padding: 6px 16px;">
                        ${window._cheatFpsEnabled ? T("Bật") : T("Tắt")}
                    </button>
                </div>
            `;
            contentHTML += `
                <div class="cheat-input-row" style="background: rgba(0,0,0,0.3);">
                    <span style="font-size: 15px; color:#00ffcc; font-weight:700;">${T("Đi Xuyên Tường")}</span>
                    <button id="btn-toggle-noclip" class="cheat-btn ${window._cheatNoClip ? 'btn-success' : 'btn-secondary'}" style="padding: 6px 16px;">
                        ${window._cheatNoClip ? T("Bật") : T("Tắt")}
                    </button>
                </div>
            `;
            contentHTML += `
                <div class="cheat-input-row" style="background: rgba(0,0,0,0.3);">
                    <span style="font-size: 15px; color:#ff99bb; font-weight:700;">${T("Unlock Thư Viện Cảnh")}</span>
                    <button id="btn-unlock-cg" class="cheat-btn btn-danger" style="padding: 6px 16px;">
                        ${T("Unlock All")}
                    </button>
                </div>
            `;
            contentHTML += `</div>`; 

            if (mapGroups.length === 0) {
                contentHTML += `<p style="color:#ef4444; text-align:center; padding: 20px; font-weight:bold;">Không thể tải dữ liệu Bản đồ!</p>`;
            } else {
                contentHTML += `<div class="cheat-grid">`;
                mapGroups.forEach(g => {
                    let options = g.children.map(c => `<option value="${c.map.id}">${c.prefix} ${c.map.name} (ID:${c.map.id})</option>`).join('');
                    contentHTML += `
                        <div class="cheat-card" style="display:flex; flex-direction:column; justify-content: space-between;">
                            <div style="color:#ffcc00; font-weight:800; margin-bottom:12px; font-size:15px; border-bottom: 1px dashed rgba(255,255,255,0.1); padding-bottom: 8px;">📍 ${g.parent.name}</div>
                            <div style="display:flex; flex-direction:column; gap:10px;">
                                <select id="sel-map-${g.parent.id}" style="width:100%; padding:10px; background:rgba(0,0,0,0.5); color:#fff; border:1px solid rgba(255,255,255,0.1); border-radius:8px; font-size:14px; outline:none; cursor:pointer; font-family:inherit;">
                                    ${options}
                                </select>
                                <button class="btn-teleport cheat-btn btn-primary" data-sel="sel-map-${g.parent.id}" style="width:100%;">${T("Dịch Chuyển")}</button>
                            </div>
                        </div>
                    `;
                });
                contentHTML += `</div>`;
            }
            contentHTML += `</div>`;

            let footerHTML = `
                <div class="cheat-footer-container">
                    <button id="btn-tp-close" class="cheat-btn btn-secondary" style="min-width: 150px;">${T("ĐÓNG MÀN HÌNH")}</button>
                </div>
            `;

            overlay.innerHTML = headerHTML + contentHTML + footerHTML;
            applyJoiPlayTouchFix('cheat-teleport-ui');

            document.getElementById('btn-toggle-fps').onclick = () => {
                SoundManager.playCursor();
                window._cheatFpsEnabled = !window._cheatFpsEnabled;
                if (window._cheatFpsEnabled) requestAnimationFrame(window._updateCheatFPS);
                else { const el = document.getElementById('cheat-fps-meter'); if (el) el.remove(); }
                renderTeleportUI(); 
            };

            document.getElementById('btn-toggle-noclip').onclick = () => {
                SoundManager.playCursor(); window._cheatNoClip = !window._cheatNoClip; renderTeleportUI(); 
            };

            document.getElementById('btn-unlock-cg').onclick = () => {
                SoundManager.playEquip();
                if(confirm(T("CẢNH BÁO: Nên Save Game trước khi sử dụng!\nChức năng này sẽ tự động chạy mã lệnh để Mở Khóa Toàn Bộ Thư Viện Hồi Tưởng/CG.\nBạn có chắc muốn tiếp tục?"))) {
					try {
						$gameSwitches.setValue(968, true);
						if (typeof ConfigManager !== 'undefined') {
							if (!ConfigManager._recalls) ConfigManager._recalls = {};
							if (typeof A !== 'undefined' && A.TitleCg && A.TitleCg.data) {
								for (let i = 1; i <= A.TitleCg.data.length + 50; i++) ConfigManager._recalls[i] = true;
							} else {
								for (let i = 1; i <= 500; i++) ConfigManager._recalls[i] = true;
							}
							ConfigManager.save();
						}
						/*
						try {
							if (typeof DataManager.saveGlobalInfo === 'function') DataManager.saveGlobalInfo();
							if ($gameSystem && typeof $gameSystem.onBeforeSave === 'function') $gameSystem.onBeforeSave();
						} catch (e) {}
						*/
						setTimeout(() => { alert(T("✅ Đã Mở Khóa Toàn Bộ Thư Viện Cảnh/CG thành công! Vui lòng kiểm tra ngoài Menu chính của game.")); }, 100);
					} catch (err) {
						setTimeout(() => { alert("❌ Có lỗi xảy ra khi chạy lệnh Unlock: " + err.message); }, 100);
					}
				}
            };
            document.querySelectorAll('.btn-teleport').forEach(btn => {
                btn.onclick = () => {
                    SoundManager.playEquip();
                    const mapId = parseInt(document.getElementById(btn.getAttribute('data-sel')).value);
                    if(confirm(T("Nên Save Game trước khi sử dụng!\nBạn có chắc muốn dịch chuyển tới Map ID: ") + mapId + "?")) {
                        document.body.removeChild(overlay);
                        Input.clear(); TouchInput.clear();
                        $gamePlayer.reserveTransfer(mapId, 10, 1, 2, 0); 
                    }
                };
            });
            closeFunc = () => {
                SoundManager.playCancel();
                document.body.removeChild(overlay);
                Input.clear(); TouchInput.clear();
            };
            document.getElementById('btn-tp-close').onclick = closeFunc;
        };
        Input.clear(); TouchInput.clear();
        document.body.appendChild(overlay);
        renderTeleportUI();
    };

    Scene_CheatMenu.prototype.cmdOpenDaoHuuUI = function() {
        SoundManager.playEquip();
        this.popScene(); 
        if (document.getElementById('cheat-daohuu-ui')) return;
        let currentDTab = 1;
        const AFFECTION_VARS = [
            { id: 74, name: "Trí Sĩ Hạo Nhiên" }, { id: 76, name: "Con Trai Trí Sĩ" },
            { id: 77, name: "Ngô Tiểu Sơn" }, { id: 78, name: "Thành Chủ 1" },
            { id: 79, name: "Thành Chủ 2" }, { id: 80, name: "Lý Sương 1" },
            { id: 81, name: "Mã Phu" }, { id: 82, name: "Tu Sĩ Vô Danh" },
            { id: 103, name: "Sư Huynh" }, { id: 168, name: "Mặc Huyền" },
            { id: 387, name: "Tình Cảm Kỹ Nữ" }, { id: 435, name: "Mục Vân Phong" },
            { id: 454, name: "Từ Trường Viễn" }, { id: 488, name: "Tình Cảm Sư Phụ" },
            { id: 489, name: "Đại Sư Huynh" }, { id: 490, name: "Nhị Sư Huynh" },
            { id: 491, name: "Sư Tỷ" }, { id: 676, name: "Hàn Ngọc" },
            { id: 683, name: "Chu Tĩnh Sơ" }, { id: 862, name: "Tông Chủ Yên Tín" },
            { id: 865, name: "Ngô Lan" }, { id: 879, name: "Vạn Niên" },
            { id: 907, name: "Vương Thư" }, { id: 911, name: "Cốc Tinh Nhiên" },
            { id: 915, name: "Triệu Minh Nguyệt" }, { id: 919, name: "Lý Ngọc Văn" },
            { id: 962, name: "Nam Yandere" }
        ];
        const HISTORY_VARS = [
            { id: 50, name: "Số Lần Quan Hệ Với Người" }, { id: 51, name: "Số Lần Quan Hệ Với Quái Vật" },
            { id: 52, name: "Số Lần Đẩy Ngã Nam Nhân" }, { id: 53, name: "Số Lần Quan Hệ Bằng Miệng" },
            { id: 54, name: "Số Lần Dùng Ngực" }, { id: 55, name: "Số Lần Quan Hệ Hậu Môn" },
            { id: 64, name: "QH Bằng Miệng Bị Điều Khiển" }, { id: 65, name: "Dùng Ngực Bị Điều Khiển" },
            { id: 66, name: "Tư Thế Doggy Bị Điều Khiển" }, { id: 73, name: "Quan hệ khi mang thai 1" },
            { id: 101, name: "Dụ Dỗ Côn Đồ Quan Hệ Tập Thể" }, { id: 128, name: "Hổ Sa Trong Trận Đấu" },
            { id: 129, name: "Tinh Tinh Trong Trận Đấu" }, { id: 130, name: "Thú Lý Trong Trận Đấu" },
            { id: 167, name: "Giai Đoạn QH Bằng Miệng 1" }, { id: 206, name: "NPC Quan Hệ Tập Thể" }
        ];
        const overlay = document.createElement('div');
        overlay.id = 'cheat-daohuu-ui';
        overlay.className = 'cheat-overlay-box';
        overlay.addEventListener('mousedown', e => e.stopPropagation());
        overlay.addEventListener('touchstart', e => e.stopPropagation());
        overlay.addEventListener('pointerdown', e => e.stopPropagation());
        // Dừng Di Chuyển khi đang nhập liệu
        let closeFunc;
        overlay.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeFunc(); });
        overlay.addEventListener('keyup', e => e.stopPropagation());
        const renderDaoHuuUI = () => {
            let tabsHTML = '<div class="cheat-tabs">';
            const tabList = [ { id: 1, name: T("HẢO CẢM & ĐẠO LỮ") }, { id: 2, name: T("KỶ LỤC TÌNH SỬ (H-STATS)") } ];
            tabList.forEach(t => {
                tabsHTML += `<button class="cheat-tab-btn ${currentDTab === t.id ? 'active' : ''}" data-idx="${t.id}">${t.name}</button>`;
            });
            tabsHTML += '</div>';
            let contentHTML = `<div class="cheat-content-area"><div class="cheat-grid" style="width: 100%; align-content: flex-start;">`;
            const activeArray = currentDTab === 1 ? AFFECTION_VARS : HISTORY_VARS;
            const activeColor = currentDTab === 1 ? "#00ffcc" : "#ff99bb";
            activeArray.forEach(v => {
                contentHTML += createSmallInputRow(T(v.name), 'inp-dh-' + v.id, $gameVariables.value(v.id), activeColor, `(ID: ${v.id})`);
            });
            contentHTML += `</div></div>`;
            let footerHTML = `
                <div class="cheat-footer-container">
                    <button id="btn-dh-close" class="cheat-btn btn-secondary">${T("ĐÓNG")}</button>
                    <button id="btn-dh-save" class="cheat-btn btn-success">${T("LƯU LẠI")}</button>
                </div>
            `;
            overlay.innerHTML = tabsHTML + contentHTML + footerHTML;
            applyJoiPlayTouchFix('cheat-daohuu-ui');
            document.querySelectorAll('.cheat-tab-btn').forEach(btn => {
                btn.onclick = (e) => {
                    currentDTab = parseInt(e.target.getAttribute('data-idx'));
                    SoundManager.playCursor(); renderDaoHuuUI();
                };
            });
            closeFunc = () => {
                SoundManager.playCancel();
                document.body.removeChild(overlay);
                Input.clear(); TouchInput.clear();
            };
            document.getElementById('btn-dh-close').onclick = closeFunc;
            document.getElementById('btn-dh-save').onclick = () => {
                SoundManager.playSave();
                const arrayToSave = currentDTab === 1 ? AFFECTION_VARS : HISTORY_VARS;
                arrayToSave.forEach(v => {
                    let el = document.getElementById('inp-dh-' + v.id);
                    if (el) {
                        let valStr = el.value.trim();
                        if (valStr !== "" && !isNaN(Number(valStr))) $gameVariables.setValue(v.id, parseInt(valStr));
                    }
                });
                alert(T("✅ Đã lưu thành công dữ liệu Tab hiện tại!"));
                Input.clear(); TouchInput.clear(); renderDaoHuuUI(); 
            };
        };
        Input.clear(); TouchInput.clear(); document.body.appendChild(overlay); renderDaoHuuUI();
    };

    Scene_CheatMenu.prototype.cmdOpenChildrenUI = function() {
        SoundManager.playEquip();
        this.popScene(); 
        if (document.getElementById('cheat-children-ui')) return;
        let currentChildIndex = 1; 
        const maxChildren = 5;
        const overlay = document.createElement('div');
        overlay.id = 'cheat-children-ui';
        overlay.className = 'cheat-overlay-box';
        overlay.addEventListener('mousedown', e => e.stopPropagation());
        overlay.addEventListener('touchstart', e => e.stopPropagation());
        overlay.addEventListener('pointerdown', e => e.stopPropagation());
        // Dừng Di Chuyển khi nhập chỉ số
        let closeFunc;
        overlay.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeFunc(); });
        overlay.addEventListener('keyup', e => e.stopPropagation());
        const renderChildrenUI = () => {
            let tabsHTML = '<div class="cheat-tabs">';
            for(let i = 1; i <= maxChildren; i++) {
                tabsHTML += `<button class="cheat-tab-btn ${i === currentChildIndex ? 'active' : ''}" data-idx="${i}">${T("Trẻ Thứ")} ${i}</button>`;
            }
            tabsHTML += '</div>';
            const vars = CHILDREN_VARS[currentChildIndex];
            let contentHTML = `<div class="cheat-content-area">`;
            contentHTML += `
                <div class="cheat-col cheat-card">
                    <h3 class="cheat-card-title" style="color:#00ffcc;">${T("Giai Đoạn Phát Triển")}</h3>
                    ${createInputRow(T('Tuổi'), 'inp-c-tuoi', $gameVariables.value(vars.tuoi), '#fff', `(ID:${vars.tuoi})`)}
                    ${createInputRow(T('Tháng'), 'inp-c-thang', $gameVariables.value(vars.thang), '#fff', `(ID:${vars.thang})`)}
                    <hr style="border: 0; border-bottom: 1px dashed rgba(255,255,255,0.1); margin: 10px 0;">
                    ${createInputRow(T('Tình Cảm'), 'inp-c-tinhcam', $gameVariables.value(vars.tinhCam), '#ff6699', `(ID:${vars.tinhCam})`)}
                    ${createInputRow(T('Thể Lực'), 'inp-c-theluc', $gameVariables.value(vars.theLuc), '#00ffcc', `(ID:${vars.theLuc})`)}
                </div>
            `;
            contentHTML += `
                <div class="cheat-col cheat-card">
                    <h3 class="cheat-card-title" style="color:#ffcc00;">${T("Chỉ Số Tư Chất")}</h3>
                    ${createInputRow(T('Nhan Sắc'), 'inp-c-nhansac', $gameVariables.value(vars.nhanSac), '#ffb3ff', `(ID:${vars.nhanSac})`)}
                    ${createInputRow(T('Trí Tuệ'), 'inp-c-tritue', $gameVariables.value(vars.triTue), '#66b3ff', `(ID:${vars.triTue})`)}
                    ${createInputRow(T('Thể Chất'), 'inp-c-thechat', $gameVariables.value(vars.theChat), '#ff6666', `(ID:${vars.theChat})`)}
                    ${createInputRow(T('Kỹ Năng Sống'), 'inp-c-sinhton', $gameVariables.value(vars.sinhTon), '#99ff99', `(ID:${vars.sinhTon})`)}
                    ${createInputRow(T('Lĩnh Ngộ'), 'inp-c-linhngo', $gameVariables.value(vars.linhNgo), '#ffff66', `(ID:${vars.linhNgo})`)}
                    <hr style="border: 0; border-bottom: 1px dashed rgba(255,255,255,0.1); margin: 10px 0;">
                    ${createInputRow(T('Thiện Lương'), 'inp-c-thienluong', $gameVariables.value(vars.thienLuong), '#00ffcc', `(ID:${vars.thienLuong})`)}
                    ${createInputRow(T('Tà Ác'), 'inp-c-taac', $gameVariables.value(vars.taAc), '#ff3333', `(ID:${vars.taAc})`)}
                </div>
            `;
            contentHTML += `</div>`;
            let footerHTML = `
                <div class="cheat-footer-container">
                    <button id="btn-c-close" class="cheat-btn btn-secondary">${T("ĐÓNG MÀN HÌNH")}</button>
                    <button id="btn-c-save" class="cheat-btn btn-primary">${T("LƯU LẠI")}</button>
                </div>
            `;
            overlay.innerHTML = tabsHTML + contentHTML + footerHTML;
            applyJoiPlayTouchFix('cheat-children-ui');
            document.querySelectorAll('.cheat-tab-btn').forEach(btn => {
                btn.onclick = (e) => {
                    currentChildIndex = parseInt(e.target.getAttribute('data-idx'));
                    SoundManager.playCursor(); renderChildrenUI();
                };
            });
            closeFunc = () => {
                SoundManager.playCancel();
                document.body.removeChild(overlay);
                Input.clear(); TouchInput.clear();
            };
            document.getElementById('btn-c-close').onclick = closeFunc;

            document.getElementById('btn-c-save').onclick = () => {
                SoundManager.playSave();
                const setVarSafe = (vId, inputId) => {
                    if (vId > 0 && document.getElementById(inputId)) {
                        let valStr = document.getElementById(inputId).value.trim();
                        if (valStr !== "" && !isNaN(Number(valStr))) $gameVariables.setValue(vId, parseInt(valStr));
                    }
                };
                setVarSafe(vars.tuoi, 'inp-c-tuoi'); setVarSafe(vars.thang, 'inp-c-thang');
                setVarSafe(vars.nhanSac, 'inp-c-nhansac'); setVarSafe(vars.triTue, 'inp-c-tritue');
                setVarSafe(vars.theChat, 'inp-c-thechat'); setVarSafe(vars.sinhTon, 'inp-c-sinhton');
                setVarSafe(vars.taAc, 'inp-c-taac'); setVarSafe(vars.linhNgo, 'inp-c-linhngo');
                setVarSafe(vars.thienLuong, 'inp-c-thienluong'); setVarSafe(vars.tinhCam, 'inp-c-tinhcam');
                setVarSafe(vars.theLuc, 'inp-c-theluc');
                
                alert(T("✅ Đã lưu thành công các chỉ số cho Đứa con thứ ") + currentChildIndex + "!");
                Input.clear(); TouchInput.clear(); renderChildrenUI(); 
            };
        };
        Input.clear(); TouchInput.clear(); document.body.appendChild(overlay); renderChildrenUI();
    }

    Scene_CheatMenu.prototype.cmdOpenUI = function() {
        SoundManager.playEquip();
        this.popScene();         
        if (document.getElementById('cheat-custom-ui')) return;
        const members = $gameParty.members();
        let currentActorIndex = 0;
        const overlay = document.createElement('div');
        overlay.id = 'cheat-custom-ui';
        overlay.className = 'cheat-overlay-box';
        overlay.addEventListener('mousedown', e => e.stopPropagation());
        overlay.addEventListener('touchstart', e => e.stopPropagation());
        overlay.addEventListener('pointerdown', e => e.stopPropagation());
        // Dừng Di Chuyển khi đang nhập chỉ số
        let closeFunc;
        overlay.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') closeFunc(); });
        overlay.addEventListener('keyup', e => e.stopPropagation());
        const renderUI = () => {
            const actor = members[currentActorIndex];
            const isMainChar = (currentActorIndex === 0);
            let tabsHTML = '<div class="cheat-tabs">';
            members.forEach((mem, idx) => {
                tabsHTML += `<button class="cheat-tab-btn ${idx === currentActorIndex ? 'active' : ''}" data-idx="${idx}">${mem.name()}</button>`;
            });
            tabsHTML += '</div>';
            let contentHTML = `<div class="cheat-content-area">`;
            contentHTML += `
                <div class="cheat-col cheat-card">
                    <h3 class="cheat-card-title" style="color:#00c6ff;">${T("Thuộc Tính Cơ Bản")}</h3>
                    ${createInputRow(T('Cấp độ (Level)'), 'inp-lvl', actor.level, '#fff', '(Level)')}
                    ${createInputRow(T('EXP Hiện Có'), 'inp-exp', actor.currentExp(), '#fff', '(EXP)')}
                    <div class="cheat-input-row">
                        <span class="cheat-input-label" style="color:#a1a1aa; font-weight:normal;">${T("EXP Lên Cấp")}</span>
                        <span style="font-size: 14px; font-weight:800; color:#fff;">${actor.nextLevelExp()}</span>
                    </div>
                    <div class="cheat-input-row">
                        <span class="cheat-input-label" style="color:#a1a1aa; font-weight:normal;">${T("EXP Max Level")}</span>
                        <span style="font-size: 14px; font-weight:800; color:#fff;">${actor.expForLevel(actor.maxLevel())}</span>
                    </div>
                    <hr style="border: 0; border-bottom: 1px dashed rgba(255,255,255,0.1); margin: 10px 0;">
                    ${createInputRow(T('Sinh lực (HP)'), 'inp-hp', actor.mhp, '#ff4b2b', '(Param 0)')}
                    ${createInputRow(T('Linh lực (MP)'), 'inp-mp', actor.mmp, '#00c6ff', '(Param 1)')}
                    ${createInputRow(T('Công kích (ATK)'), 'inp-atk', actor.param(2), '#fff', '(Param 2)')}
                    ${createInputRow(T('Phòng ngự (DEF)'), 'inp-def', actor.param(3), '#fff', '(Param 3)')}
                    ${createInputRow(T('Phép công (MAT)'), 'inp-mat', actor.param(4), '#fff', '(Param 4)')}
                    ${createInputRow(T('Phép phòng ngự (MDF)'), 'inp-mdf', actor.param(5), '#fff', '(Param 5)')}
                    ${createInputRow(T('Thân pháp (AGI)'), 'inp-agi', actor.param(6), '#fff', '(Param 6)')}
                    ${createInputRow(T('Ngộ tính (LUK)'), 'inp-luk', actor.param(7), '#fff', '(Param 7)')}
                </div>
            `;
            if (isMainChar) {
                contentHTML += `
                    <div class="cheat-col cheat-card" style="flex:1.2;">
                        <h3 class="cheat-card-title" style="color:#ff99bb;">${T("Thông Tin Đặc Biệt")}</h3>
                        ${createInputRow(T('Công Đức'), 'inp-v8', $gameVariables.value(8), '#fff', '(ID: 8)')}
                        ${createInputRow(T('Danh Vọng'), 'inp-v13', $gameVariables.value(13), '#fff', '(ID: 13)')}
                        ${createInputRow(T('Linh Thạch'), 'inp-v16', $gameVariables.value(16), '#00ffcc', '(ID: 16)')}
                        ${createInputRow(T('Tinh Khí'), 'inp-v9', $gameVariables.value(9), '#fff', '(ID: 9)')}
                        ${createInputRow(T('Độ Thụ Thai'), 'inp-v5', $gameVariables.value(5), '#ff6699', '(ID: 5)')}
                        ${createInputRow(T('Tâm Ma'), 'inp-v7', $gameVariables.value(7), '#ff4444', '(ID: 7)')}
                        ${createInputRow(T('Mị Lực'), 'inp-v6', $gameVariables.value(6), '#ffb3ff', '(ID: 6)')}
                        
                        <div style="text-align:center; color:#ff99bb; font-size:12px; font-weight:800; margin:15px 0 10px 0; opacity:0.8;">${T("-- CÁC TIẾN ĐỘ --")}</div>
                        ${createInputRowWithTierDoaLac(T('Đọa Lạc'), 'inp-v4', $gameVariables.value(4), '(ID: 4)')}
                        ${createInputRowWithTier(T('Tiến độ Miệng'), 'inp-v22', $gameVariables.value(22), '(ID: 22)')}
                        ${createInputRowWithTier(T('Tiến độ Ngực'), 'inp-v23', $gameVariables.value(23), '(ID: 23)')}
                        ${createInputRowWithTier(T('Tiến độ Bướm'), 'inp-v24', $gameVariables.value(24), '(ID: 24)')}
                        ${createInputRowWithTier(T('Tiến độ Lỗ Nhị'), 'inp-v25', $gameVariables.value(25), '(ID: 25)')}
                        
                        <div style="text-align:center; color:#ff99bb; font-size:12px; font-weight:800; margin:15px 0 10px 0; opacity:0.8;">${T("-- SỐ LẦN SỰ KIỆN --")}</div>
                        ${createInputRow(T('Số Lần Tự Sướng'), 'inp-v26', $gameVariables.value(26), '#fff', '(ID: 26)')}
                        ${createInputRow(T('Bị Quấy Rối'), 'inp-v27', $gameVariables.value(27), '#fff', '(ID: 27)')}
                        ${createInputRow(T('Dụ Dỗ'), 'inp-v28', $gameVariables.value(28), '#fff', '(ID: 28)')}
                        ${createInputRow(T('Song Tu'), 'inp-v29', $gameVariables.value(29), '#fff', '(ID: 29)')}
                        ${createInputRow(T('Cưỡng Hiếp'), 'inp-v32', $gameVariables.value(32), '#fff', '(ID: 32)')}
                        ${createInputRow(T('Cưỡng Hiếp Tập Thể'), 'inp-v33', $gameVariables.value(33), '#fff', '(ID: 33)')}
                    </div>
                `;
            } else {
                contentHTML += `
                    <div class="cheat-col cheat-card" style="flex:1.2; justify-content:center; align-items:center; color:#a1a1aa; text-align:center;">
                        <i style="line-height: 1.6;">${T("(Đây là Linh Thú / Bạn đồng hành.<br>Các trạng thái tư mật chỉ áp dụng cho Nữ Chính.)")}</i>
                    </div>
                `;
            }

            contentHTML += `<div class="cheat-col cheat-card"><h3 class="cheat-card-title" style="color:#38ef7d;">${T("Kỹ Năng & Cấp Độ")}</h3>`;
            const skills = actor.skills();
            if (skills.length === 0) {
                contentHTML += `<p style="text-align:center; color:#a1a1aa;">${T("Nhân vật chưa có kỹ năng nào.")}</p>`;
            } else {
                skills.forEach(skill => {
                    let lvl = 1;
                    if (actor.skillLevel) lvl = actor.skillLevel(skill.id);
                    else if (actor._skillLevels && actor._skillLevels[skill.id]) lvl = actor._skillLevels[skill.id];

                    contentHTML += `
                    <div class="cheat-input-row" style="background: rgba(0,0,0,0.3);">
                        <span style="font-size: 14px; font-weight:700; color:#38ef7d; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;" title="${skill.name}">[S:${skill.id}] ${skill.name}</span>
                        <input type="number" class="cheat-input skill-inp" data-id="${skill.id}" value="${lvl}" onfocus="this.select()" style="width: 60px;">
                    </div>`;
                });
            }
            contentHTML += `</div></div>`;

            let footerHTML = `
                <div class="cheat-footer-container">
                    <button id="btn-close" class="cheat-btn btn-secondary">${T("ĐÓNG MÀN HÌNH")}</button>
                    <button id="btn-save" class="cheat-btn btn-danger">${T("LƯU LẠI")}</button>
                </div>
            `;
            overlay.innerHTML = tabsHTML + contentHTML + footerHTML;
            applyJoiPlayTouchFix('cheat-custom-ui');
            document.querySelectorAll('.tier-input').forEach(inp => {
                inp.addEventListener('input', (e) => {
                    const id = e.target.getAttribute('data-id');
                    const tierLabel = document.getElementById('tier-' + id);
                    if (tierLabel) tierLabel.innerText = '[' + getTierName(e.target.value) + ']';
                });
            });
            document.querySelectorAll('.cheat-tab-btn').forEach(btn => {
                btn.onclick = (e) => {
                    currentActorIndex = parseInt(e.target.getAttribute('data-idx'));
                    SoundManager.playCursor(); renderUI();
                };
            });
            closeFunc = () => {
                SoundManager.playCancel();
                document.body.removeChild(overlay);
                Input.clear(); TouchInput.clear();
            };
            document.getElementById('btn-close').onclick = closeFunc;
            document.getElementById('btn-save').onclick = () => {
                SoundManager.playSave();
                const getSafeVal = (id, defVal) => {
                    let el = document.getElementById(id);
                    if (!el) return defVal;
                    let str = el.value.trim();
                    return (str === "" || isNaN(Number(str))) ? defVal : parseInt(str);
                };
                const newLvl = getSafeVal('inp-lvl', actor.level);
                if (newLvl !== actor.level) actor.changeLevel(newLvl, false);
                actor.changeExp(getSafeVal('inp-exp', actor.currentExp()), false);
                const params = [
                    { id: 0, val: getSafeVal('inp-hp', actor.mhp) }, { id: 1, val: getSafeVal('inp-mp', actor.mmp) },
                    { id: 2, val: getSafeVal('inp-atk', actor.param(2)) }, { id: 3, val: getSafeVal('inp-def', actor.param(3)) },
                    { id: 4, val: getSafeVal('inp-mat', actor.param(4)) }, { id: 5, val: getSafeVal('inp-mdf', actor.param(5)) },
                    { id: 6, val: getSafeVal('inp-agi', actor.param(6)) }, { id: 7, val: getSafeVal('inp-luk', actor.param(7)) }
                ];
                params.forEach(p => {
                    const diff = p.val - actor.param(p.id);
                    if (diff !== 0) actor.addParam(p.id, diff);
                });
                actor.setHp(actor.mhp); actor.setMp(actor.mmp);
                document.querySelectorAll('.skill-inp').forEach(inp => {
                    const skillId = parseInt(inp.getAttribute('data-id'));
                    let str = inp.value.trim();
                    if (str !== "" && !isNaN(Number(str))) {
                        const val = parseInt(str);
                        if (actor.setSkillLevel) actor.setSkillLevel(skillId, val);
                        if (!actor._skillLevels) actor._skillLevels = {};
                        actor._skillLevels[skillId] = val; 
                    }
                });
                if (isMainChar) {
                    const setMainVar = (vId, inputId) => {
                        let el = document.getElementById(inputId);
                        if (el && el.value.trim() !== "" && !isNaN(Number(el.value.trim()))) {
                            $gameVariables.setValue(vId, parseInt(el.value.trim()));
                        }
                    };
                    [8, 13, 16, 9, 5, 4, 6, 7, 22, 23, 24, 25, 26, 27, 28, 29, 32, 33].forEach(id => setMainVar(id, 'inp-v' + id));
                }
                alert(T("✅ Đã lưu thành công mọi chỉ số cho ") + actor.name() + "!");
                Input.clear(); TouchInput.clear(); renderUI(); 
            };
        };
        Input.clear(); TouchInput.clear(); document.body.appendChild(overlay); renderUI();
    }
    // =====================================================================
    // CÁC HÀM CHEAT CƠ BẢN 
    // =====================================================================
    Scene_CheatMenu.prototype.resumeMenu = function(msg) {
        Input.clear(); TouchInput.clear();
        if(msg) {
            setTimeout(() => { alert(msg); Input.clear(); TouchInput.clear(); if (this._cheatWindow) this._cheatWindow.activate(); }, 200);
        } else {
            setTimeout(() => { if (this._cheatWindow) this._cheatWindow.activate(); }, 200);
        }
    };
    Scene_CheatMenu.prototype.cmdGold = function() {
        $gameParty.gainGold(99999999);
        if ($dataItems[53]) $gameParty.gainItem($dataItems[53], 9999999);
        if ($dataItems[61]) $gameParty.gainItem($dataItems[61], 9999999);
        SoundManager.playShop();
        this.resumeMenu(T("✅ Đã nhận 1 Tỷ Vàng, Linh Thạch & Thẻ Điểm!"));
    };
    Scene_CheatMenu.prototype.cmdVipItems = function() {
        VIP_ITEMS.forEach(id => { if($dataItems[id]) $gameParty.gainItem($dataItems[id], 99); });
        SoundManager.playUseItem(); this.resumeMenu(T("✅ Đã nhận rương Đan Dược VIP!"));
    };
    Scene_CheatMenu.prototype.cmdVipGear = function() {
        VIP_WEAPONS.forEach(id => { if($dataWeapons[id]) $gameParty.gainItem($dataWeapons[id], 1); });
        VIP_ARMORS.forEach(id => { if($dataArmors[id]) $gameParty.gainItem($dataArmors[id], 1); });
        SoundManager.playEquip(); this.resumeMenu(T("✅ Đã nhận Trang Bị VIP!"));
    };
    Scene_CheatMenu.prototype.cmdMaxLevel = function() {
        $gameParty.members().forEach(actor => { actor.changeLevel(actor.maxLevel(), true); });
        SoundManager.playRecovery(); this.resumeMenu(T("✅ Tất cả thành viên đã Max Level!"));
    };
    Scene_CheatMenu.prototype.cmdAllSkills = function() {
        $gameParty.members().forEach(actor => {
            for(let i=1; i<$dataSkills.length; i++){ if($dataSkills[i]) actor.learnSkill(i); }
        });
        SoundManager.playRecovery(); this.resumeMenu(T("✅ Đã hack học toàn bộ Skill trong game!"));
    };
    Scene_CheatMenu.prototype.cmdGodMode = function() {
        $gameParty.members().forEach(actor => {
            for(let i=0; i<8; i++){ actor.addParam(i, 9999); }
            actor._hp = actor.mhp; actor._mp = actor.mmp;
        });
        SoundManager.playMagicEvasion(); this.resumeMenu(T("✅ Đã buff chỉ số lên 9999 (God Mode)!"));
    };
    Scene_CheatMenu.prototype.cmdFullHeal = function() {
        $gameParty.members().forEach(actor => { actor.recoverAll(); });
        SoundManager.playRecovery(); this.resumeMenu(T("✅ Đã hồi phục hoàn toàn máu và mana!"));
    };
    Scene_CheatMenu.prototype.cmdAddVariable = function() {
        Input.clear(); TouchInput.clear();
        setTimeout(() => {
            const idStr = prompt(T("Nhập ID Biến số (Variable ID) muốn thao tác:\n(Mở Copy List Biến Số để tra ID)"));
            if (!idStr) return this.resumeMenu();
            const id = Number(idStr);
            const varName = $dataSystem.variables[id] || T("Biến ẩn/Không tên");
            const currentVal = Number($gameVariables.value(id)) || 0;
            const addValStr = prompt(T("Chỉ số [") + varName + T("] hiện tại đang là: ") + currentVal + T("\nNhập số điểm muốn CỘNG THÊM (Nhập số âm dấu trừ để giảm):"), "100");
            if (!addValStr) return this.resumeMenu();
            const addVal = Number(addValStr);
            $gameVariables.setValue(id, currentVal + addVal);
            SoundManager.playRecovery();
            this.resumeMenu(T("✅ Đã cộng thêm ") + addVal + T(" vào [") + varName + T("].\nTổng hiện tại: ") + (currentVal + addVal));
        }, 100);
    };
    function copyToClipboard(text) {
        const tempInput = document.createElement("textarea");
        tempInput.value = text;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
    }
    Scene_CheatMenu.prototype.cmdListAllItems = function() {
        let text = T("--- DANH SACH ITEM ---\n");
        for (let i = 1; i < $dataItems.length; i++) { if ($dataItems[i] && $dataItems[i].name) text += i + " = " + $dataItems[i].name + "\n"; }
        text += T("\n--- DANH SACH VU KHI ---\n");
        for (let i = 1; i < $dataWeapons.length; i++) { if ($dataWeapons[i] && $dataWeapons[i].name) text += i + " = " + $dataWeapons[i].name + "\n"; }
        text += T("\n--- DANH SACH GIAP ---\n");
        for (let i = 1; i < $dataArmors.length; i++) { if ($dataArmors[i] && $dataArmors[i].name) text += i + " = " + $dataArmors[i].name + "\n"; }
        copyToClipboard(text);
        this.resumeMenu(T("✅ Đã Copy toàn bộ ID Vật phẩm/Vũ khí/Giáp!\nRa ngoài mở Notepad Paste (Ctrl+V) ra xem."));
    };
    Scene_CheatMenu.prototype.cmdListVariables = function() {
        let text = T("--- DANH SACH BIEN SO (VARIABLES) ---\n");
        for (let i = 1; i < $dataSystem.variables.length; i++) {
            if ($dataSystem.variables[i] && $dataSystem.variables[i].trim() !== "") text += i + " = " + $dataSystem.variables[i] + "\n";
        }
        copyToClipboard(text);
        this.resumeMenu(T("✅ Đã Copy danh sách Biến!\nRa ngoài mở Notepad Paste (Ctrl+V) để tra ID."));
    };
    const _update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _update.call(this);
        if(Input.isTriggered("cheatMenu")){
            // Ngăn việc mở menu mới nếu các bảng UI đã đang mở
            if (document.getElementById('cheat-custom-ui') || document.getElementById('cheat-children-ui') || document.getElementById('cheat-daohuu-ui') || document.getElementById('cheat-teleport-ui') || document.getElementById('cheat-items-ui')) return;
            if (!window._cheatMenuLanguage) {
                Input.clear();
                TouchInput.clear();
				let isEng = confirm("CHỌN NGÔN NGỮ / SELECT LANGUAGE\n\n👉 Press 'OK' to use English.\n👉 Nhấn 'Cancel / Hủy' để dùng Tiếng Việt.");
                window._cheatMenuLanguage = isEng ? 'EN' : 'VN';
                setTimeout(() => SceneManager.push(Scene_CheatMenu), 200);
            } else {
                SceneManager.push(Scene_CheatMenu);
            }
        }
    };
})();